#!/usr/bin/env python
# -*- encoding=utf8 -*-

"""

 author:  Konia Zheng
 mail:    konia@maxln.com
 time:    2017.06.08

 file:          nft.py
 description:   `sudo nft` wrapper. 
 
    ** Rewrite this file if `pyroute2` is ready to manipulate nftables.**


"""

import os
import re
import subprocess


class NFT(object):
    def __init__(self, family="ip", nft_cmd="sudo nft"):
        self.nft_cmd = nft_cmd
        self.family = family

        self.table_family = ["ip", "arp", "ip6", "bridge", "inet", "netdev"]
        self.chain_type = ["filiter", "route", "nat"]
        self.chain_hook = ["input", "prerouting", "forward", "output", "postrouting", "ingress"]

    @classmethod
    def _get_ipaddr(cls):
        """
        - run `ip addr` to get output.
        - parse output to generate interface's ip addr.
        :return: { INTERFACE : IPADDR }
        """
        status, ip_info = cls._run_cmd(["ip addr"])

        net_list = re.findall(r'[0-9]+:\s+([^:]+):', ip_info)
        ipaddr_list = re.findall(r'inet ([0-9.]+)', ip_info)

        ipaddr = dict(zip(net_list, ipaddr_list))

        if "lo" in ipaddr:
            ipaddr.pop("lo")

        return ipaddr

    @property
    def ipaddr(self):
        """
        :return: { INTERFACE : IPADDR } 
        """
        return self._get_ipaddr()

    def check_table_family(self, table_family):
        """
        check table_family and return a valid table_family.
        """
        return table_family if table_family in self.table_family else self.table_family[0]

    def check_chain_type(self, chain_type):
        """
        check chain_type and return a valid chain type.
        """
        return chain_type if chain_type in self.chain_type else self.chain_type[0]

    def check_chain_hook(self, chain_hook):
        """
        check chain_hook and return a valid chain hook.
        """
        return chain_hook if chain_hook in self.chain_hook else self.chain_hook[0]

    @staticmethod
    def _run_cmd(command_list, shell=True):
        """
        using commands to run command
        return: status, result
        """
        if command_list and (isinstance(command_list, list) or isinstance(command_list, tuple)):
            process = subprocess.Popen(command_list, shell=shell, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            process.wait()
            if process.returncode == 0:
                stdout, stderr = process.communicate()
                result = 0, stdout
            else:
                stdout, stderr = process.communicate()
                result = process.returncode, stderr
        else:
            result = 1, "command is Nil"
        return result

    @property
    def tables(self):
        """
        :return: tables list
        """
        status, tables_info = self.operate_table("list", table="")
        if status == 0:
            tables_data = re.findall(r'table %s (.*)' % self.family, tables_info)
        else:
            tables_data = []
        return tables_data

    @property
    def chains(self):
        """
        :return: chains list
        """
        chains_data = {}
        for table in self.tables:
            chains_data[table] = {}
            status, chains_info = self.operate_table("list", table=table, chain="")
            if status == 0:
                chains_match = re.findall(r'chain ([^ ]+) {\n\t\ttype ([^ ]+) hook ([^ ]+) priority ([^;]+);',
                                          chains_info)

                for chain_name, chain_type, chain_hook, chain_priority in chains_match:
                    chains_data[table][chain_name] = {
                        "type": chain_type,
                        "hook": chain_hook,
                        "priority": chain_priority
                    }

        return chains_data

    @property
    def rules(self):
        """
        :return: rules list
        """
        status, output = self.operate_ruleset("lists")
        rules_data = {}

        if status == 0:
            tables = output.split("\ntable ")

            for table in tables:
                table_names = re.findall(r'%s ([^ ]+) {' % self.family, table)

                if not table_names:
                    continue

                table_name = table_names[0]

                chains = re.findall(r'chain ([^ ]+) {([^}]+)}', table, re.M)
                for chain in chains:
                    chain_name = chain[0]
                    chain_rule = chain[1].replace("\t", "").split("\n")
                    rule_set = {}

                    for rule_data in chain_rule:
                        rule_list = rule_data.split(" # handle ")
                        if rule_list and len(rule_list) > 1:
                            rule, handle = rule_list
                            rule_set[handle] = rule

                    if table_name not in rules_data:
                        rules_data[table_name] = {chain_name: rule_set}
                    else:
                        rules_data[table_name][chain_name] = rule_set

        return rules_data

    @property
    def maps(self):
        """
        :return: maps list
        """
        maps_data = {}
        for table in self.tables:
            maps_data[table] = {}
            status, chains_info = self.operate_table("list", table=table, chain=None)
            if status == 0:
                chains_match = re.findall(r'map ([^ ]+) {\n\t\ttype ([^ ]+) : (.*)', chains_info)

                for map_name, map_key_type, map_value_type in chains_match:
                    maps_data[table][map_name] = {
                        "k_type": map_key_type,
                        "v_type": map_value_type
                    }

        return maps_data

    @property
    def sets(self):
        """
        :return: sets list
        """
        maps_data = {}
        for table in self.tables:
            maps_data[table] = {}
            status, chains_info = self.operate_table("list", table=table, chain=None)
            if status == 0:
                sets_match = re.findall(r'set ([^ ]+) {\n\t\ttype ([^ ]+)\n', chains_info)

                for set_name, set_type in sets_match:
                    maps_data[table][set_name] = {
                        "type": set_type,
                    }

        return maps_data

    @property
    def map_elements(self):
        """
        :return: map element list
        """
        status, output = self.operate_ruleset("lists")
        element_data = {}

        if status == 0:
            tables = output.split("\ntable ")

            for table in tables:
                table_names = re.findall(r'%s ([^ ]+) {' % self.family, table)
                if not table_names:
                    continue

                table_name = table_names[0]
                maps = re.findall(r'map ([^ ]+) {([^}]+)}', table, re.M)
                for map_name, map_value in maps:
                    elements = re.findall(r'([0-9]+)\s+:\s+([0-9.]+)', map_value, re.M)

                    for port, port_value in elements:
                        if table_name not in element_data:
                            element_data[table_name] = {map_name: {port: port_value}}
                        elif map_name not in element_data[table_name]:
                            element_data[table_name][map_name] = {port: port_value}
                        elif port not in element_data[table_name][map_name]:
                            element_data[table_name][map_name][port] = port_value

        return element_data

    @property
    def set_elements(self):
        """
        :return: set element list
        """
        status, output = self.operate_ruleset("lists")
        element_data = {}

        if status == 0:
            tables = output.split("\ntable ")

            for table in tables:
                table_names = re.findall(r'%s ([^ ]+) {' % self.family, table)
                if not table_names:
                    continue

                table_name = table_names[0]
                maps = re.findall(r'set ([^ ]+) {([^}]+})', table, re.M)
                for map_name, map_value in maps:
                    elements_area = re.findall(r'elements = {([^}]+)}', map_value, re.M)

                    if not elements_area:
                        continue

                    elements = re.findall(r'([0-9.]+)', elements_area[0], re.M)

                    for value in elements:
                        if table_name not in element_data:
                            element_data[table_name] = {map_name: [value]}
                        elif map_name not in element_data[table_name]:
                            element_data[table_name][map_name] = [value]
                        elif value not in element_data[table_name][map_name]:
                            element_data[table_name][map_name].append(value)

        return element_data

    @property
    def elements(self):
        """
        :return: map_element
        """
        return self.map_elements

    def operate_table(self, method, table, **kwargs):
        """
        operate nftables' table
        :param method: 
        
            * add
            * delete
            * flush
            * list   default, when table is not null
            * lists  default, when list fails.
        
        :param table: 
        :param kwargs: 
        :return: 
        """
        table_family = self.check_table_family(kwargs.get("family", self.family))

        if table:
            if method in ["add", "delete", "flush"]:
                if table:
                    command_list = [method, "table",
                                    table_family, table]
                else:
                    command_list = []
            else:
                command_list = ["list table",
                                table_family, table]

                if kwargs.get("all"):
                    command_list.append("-a")

                if kwargs.get("numerical"):
                    command_list.append("-nn")
        else:
            command_list = ["list tables", table_family]

        return self.operate(command_list)

    def operate_chain(self, method, table, chain, **kwargs):
        """
        operate nftables' chain
        :param method: 
        
            * add
            * create
            * delete
            * flush
            * rename
            * list   default, when table && chain are not null
            * lists  default, when list fails.
        
        :param table: 
        :param chain: 
        :param kwargs: 
        :return: 
        """
        table_family = self.check_table_family(kwargs.get("family", self.family))

        if method in ["add", "create"]:
            chain_type = self.check_chain_type(kwargs.get("type"))
            chain_hook = self.check_chain_hook(kwargs.get("hook"))
            chain_priority = int(kwargs.get("priority", 1000))

            command_list = [method, "chain",
                            table_family,
                            table,
                            chain,
                            "{ type %s hook %s priority %d \; policy accept \; }" % (chain_type, chain_hook,
                                                                                     chain_priority)
                            ]

        elif method in ["delete", "flush"]:
            command_list = [method, "chain", table_family, table, chain]
        elif method == "rename" and kwargs.get("name"):
            command_list = ["rename chain", table_family, table, chain, kwargs["name"]]
        elif table and chain:
            command_list = ["list chain", table_family, table, chain]

            if kwargs.get("all"):
                command_list.append("-a")

            if kwargs.get("numerical"):
                command_list.append("-nn")
        else:
            command_list = ["list chains"]

        return self.operate(command_list)

    def operate_map(self, method, table, map_name, **kwargs):
        """
        operate nftables' map
        :param method: 
        
                * init
                * add
                * pop
                * delete
                * list   default, when table && map_name are not null
                * lists  default, when list fails.

        :param table: 
        :param map_name: 
        :param kwargs: 
        :return: 
        """
        table_family = self.check_table_family(kwargs.get("family", self.family))

        if method == "init" and kwargs.get("map_type"):
            command_list = ["add map",
                            table_family,
                            table,
                            map_name,
                            "{ type %s : %s \; }" % (kwargs["map_type"][0], kwargs["map_type"][1])
                            ]
        elif method == "add" and kwargs.get("element"):
            command_list = ["add element",
                            table_family,
                            table,
                            map_name,
                            str(kwargs["element"])
                            ]
        elif method == "pop" and kwargs.get("element"):
            command_list = ["delete element",
                            table_family,
                            table,
                            map_name,
                            str(kwargs["element"])
                            ]
        elif method == "delete":
            command_list = ["delete map",
                            table_family,
                            table,
                            map_name
                            ]
        elif table and map_name:
            command_list = ["list map",
                            table_family,
                            table,
                            map_name,
                            "-nn"
                            ]
        else:
            command_list = ["list maps"]

        return self.operate(command_list)

    def operate_set(self, method, table, set_name, **kwargs):
        """
        operate nftables' set
        :param method: 
        
                * init
                * add
                * pop
                * delete
                * list   default, when table && set_name are not null
                * lists  default, when list fails.
        
        :param table: 
        :param set_name: 
        :param kwargs: 
        :return: 
        """
        table_family = self.check_table_family(kwargs.get("family", self.family))

        if method == "init" and kwargs.get("set_type"):
            command_list = ["add set",
                            table_family,
                            table,
                            set_name,
                            "{ type %s \; }" % (kwargs["set_type"])
                            ]
        elif method == "add" and kwargs.get("element"):
            command_list = ["add element",
                            table_family,
                            table,
                            set_name,
                            str(kwargs["element"])
                            ]
        elif method == "pop" and kwargs.get("element"):
            command_list = ["delete element",
                            table_family,
                            table,
                            set_name,
                            str(kwargs["element"])
                            ]
        elif method == "delete":
            command_list = ["delete set",
                            table_family,
                            table,
                            set_name
                            ]
        elif table and set_name:
            command_list = ["list set",
                            table_family,
                            table,
                            set_name,
                            "-nn"
                            ]
        else:
            command_list = ["list sets"]

        return self.operate(command_list)

    def operate_rule(self, method, table, chain, match_rule, **kwargs):
        """
        operate nftables' rule
        :param method: 
        
            * add
            * insert
            * replace
            * delete
            * list   default, when table && chain are not null
        
        :param table: 
        :param chain: 
        :param match_rule: 
        :param kwargs: 
        :return: 
        """
        table_family = self.check_table_family(kwargs.get("family", self.family))

        if method == "add":
            command_list = ["add rule", table_family, table, chain, match_rule]
        elif method == "insert":
            position = kwargs.get("position", 0)
            command_list = ["add rule",
                            table_family,
                            table,
                            chain, "position %d" % position, match_rule]
        elif method == "replace" and kwargs.get("handle"):
            command_list = ["replace rule",
                            table_family,
                            table,
                            chain, "handle %s" % str(kwargs["handle"]), match_rule]

        elif method == "delete" and kwargs.get("handle"):
            command_list = ["delete rule",
                            table_family,
                            table,
                            chain, "handle %s" % str(kwargs["handle"])]
        elif table and chain:
            command_list = ["list chains",
                            table_family,
                            table, chain, "-n -a"]
        else:
            command_list = []

        return self.operate(command_list)

    def operate_ruleset(self, method, **kwargs):
        """
        operate nftables' ruleset
        :param method: 
        
            * flush
            * save
            * restore
            * list default.
        
        :param kwargs: 
        :return: 
        """
        command_list = ["list", "ruleset", "-nn", "-a"]

        if method == "flush":
            command_list = ["flush", "ruleset"]

        if method == "load":
            file_path = kwargs.get("file")

            if os.path.isfile(file_path):
                command_list = ["-f", file_path]

        elif method == "save":
            file_path = kwargs.get("file")
            if file_path:
                command_list = ["list", "ruleset", "-nn", ">", file_path]

        return self.operate(command_list)

    def operate(self, command_list):
        """
        handle nftables operate
        :param command_list: []
        :return: 
        """
        return self._run_cmd(["{0} {1}".format(self.nft_cmd, " ".join(command_list))]) if command_list else (
            1, "empty command request")


if __name__ == '__main__':
    import sys
    import json


    def check(nft, item):
        element = getattr(nft, item, None)
        if element is not None:
            print json.dumps(nft.chains, indent=2)
        else:
            print "accept [tables/chains/rules/maps/elements]"


    if len(sys.argv) > 1:
        check(NFT(), sys.argv[1])
    else:
        print "accept [tables/chains/rules/maps/elements]"
