#!/usr/bin/env python
# -*- encoding=utf8 -*-

import argparse


class Utils(object):
    @staticmethod
    def parse_args(parser, cmd_options):
        for optkey, optlist in cmd_options.iteritems():
            if isinstance(optlist[1], dict):
                parms = optlist[1]

            elif isinstance(optlist[1], list):
                parms = {
                    "action": optlist[1][0],
                    "default": optlist[1][1],
                    "help": optlist[1][2],
                    "dest": optkey
                }

                if len(optlist) > 5:
                    parms["type"] = optlist[5]
            else:
                parms = {}

            parser.add_argument(*optlist[0], **parms)

        return parser

    @classmethod
    def commands_parse(cls, options):
        parser = argparse.ArgumentParser(prog=options["name"])
        cls.parse_args(parser, options.get("default", {}))
        subparsers = parser.add_subparsers(dest="subparsers")

        for subparsers_name, subparsers_opts in options.get("subparsers", {}).iteritems():
            the_subparsers = subparsers.add_parser(subparsers_name, help=subparsers_opts[0])
            cls.parse_args(the_subparsers, subparsers_opts[1])

        args = parser.parse_args()
        return args
