#!/usr/bin/env python
# -*- encoding=utf8 -*-

from utils import Utils
from nfttool import NFTTool


def command_pars():
    command_config = {
        "name": "Nftables Management -- Pynft",
        "default": {},
        "subparsers": {
            "list": [
                "nftables rule/tables list",
                {
                    "tables": [
                        ["--tables"],
                        {"action": "store_true", "default": False, "help": "nft list tables", "dest": "tables"}
                    ],
                    "chains": [
                        ["--chains"],
                        {"action": "store_true", "default": False, "help": "nft list chains", "dest": "chains"}
                    ],
                    "rules": [
                        ["--rules"],
                        {"action": "store_true", "default": False, "help": "nft list rules", "dest": "rules"}
                    ],
                    "maps": [
                        ["--maps"],
                        {"action": "store_true", "default": False, "help": "nft list maps", "dest": "maps"}
                    ],
                    "sets": [
                        ["--sets"],
                        {"action": "store_true", "default": False, "help": "nft list sets", "dest": "sets"}
                    ],
                    "elements": [
                        ["--elements"],
                        {"action": "store_true", "default": False, "help": "nft list elements", "dest": "elements"}
                    ],
                }
            ],
            "save": [
                "save nftables rule to file",
                {
                    "file": [
                        ["-f", "--file"],
                        {"action": "store", "default": "/etc/nftables.netease", "help": "export nftables rule",
                         "dest": "file"}
                    ]
                }
            ],
            "restore": [
                "restore nftables rule from file",
                {
                    "file": [
                        ["-f", "--file"],
                        {"action": "store", "default": "/etc/nftables.netease", "help": "export nftables rule",
                         "dest": "file"}
                    ]
                }
            ],
            "natinit": [
                "init nat chain for specify project and nat's ip", {
                    "project": [
                        ["-p", "--project"],
                        {"action": "store", "default": "", "help": "project for setting chain", "dest": "project"}
                    ],
                    "ip": [
                        ["-i", "--ip"],
                        {"action": "store", "default": "", "help": "nat ip for setting chain", "dest": "ip"}
                    ],
                    "enable_tcp": [
                        ["--no-tcp"],
                        {"action": "store_false", "default": True, "help": "enable tcp service", "dest": "enable_tcp"}
                    ],
                    "enable_udp": [
                        ["--with-udp"],
                        {"action": "store_true", "default": False, "help": "enable udp service", "dest": "enable_udp"}
                    ],
                }
            ],
            "natclear": [
                "init nat chain for specify project and nat's ip", {
                    "project": [
                        ["-p", "--project"],
                        {"action": "store", "default": "", "help": "project for setting chain", "dest": "project"}
                    ],
                    "ip": [
                        ["-i", "--ip"],
                        {"action": "store", "default": "", "help": "nat ip for setting chain", "dest": "ip"}
                    ],
                    "enable_tcp": [
                        ["--no-tcp"],
                        {"action": "store_false", "default": True, "help": "enable tcp service", "dest": "enable_tcp"}
                    ],
                    "enable_udp": [
                        ["--with-udp"],
                        {"action": "store_true", "default": False, "help": "enable udp service", "dest": "enable_udp"}
                    ],
                }
            ],
            "natlist": [
                "list nat port hash for specify project", {
                    "project": [
                        ["-p", "--project"],
                        {"action": "store", "default": "", "help": "project for setting chain", "dest": "project"}
                    ]
                }
            ],
            "natadd": [
                "adding [update] nat port rule ", {
                    "project": [
                        ["-p", "--project"],
                        {"action": "store", "default": "", "help": "project for setting chain", "dest": "project"}
                    ],
                    "ip": [
                        ["-i", "--ip"],
                        {"action": "store", "default": "", "help": "nat ip addr for setting chain", "dest": "ip"}
                    ],
                    "port": [
                        ["--port"],
                        {"action": "store", "default": "", "help": "port for setting map", "dest": "port"}
                    ],
                    "daddr": [
                        ["--daddr"],
                        {"action": "store", "default": "", "help": "dest ip addr for setting chain", "dest": "daddr"}
                    ],
                    "dport": [
                        ["--dport"],
                        {"action": "store", "default": "", "help": "dest port for setting chain", "dest": "dport"}
                    ]
                }
            ],
            "natpop": [
                "pop [remove] nat port rule ", {
                    "project": [
                        ["-p", "--project"],
                        {"action": "store", "default": "", "help": "project for setting chain", "dest": "project"}
                    ],
                    "ip": [
                        ["-i", "--ip"],
                        {"action": "store", "default": "", "help": "nat ip addr for setting chain", "dest": "ip"}
                    ],
                    "port": [
                        ["--port"],
                        {"action": "store", "default": "", "help": "port for setting map", "dest": "port"}
                    ],
                }
            ],
        }
    }
    cmd_opts = Utils.commands_parse(command_config)
    return vars(cmd_opts)


def main():
    nft_handle = NFTTool()
    cmd_handle = command_pars()
    cmd_method = getattr(nft_handle, cmd_handle["subparsers"], None)

    if cmd_method:
        cmd_method(**cmd_handle)
    else:
        print "not support method"


if __name__ == '__main__':
    """
        Usage:
            - show :    python -m pynft list [--ruleset; --tables]
            - save :    python -m pynft save [--file /etc/nftables.conf]
            - restore:  python -m pynft restore [--file /etc/nftables.conf]
            - init:     python -m pynft init [--table] [--type nat/filiter/route] [--priority 100]
            - nat:      python -m pynft natinit --project --ip
            - nat:      python -m pynft natlist --project 
            - nat:      python -m pynft natadd  --project --ip --port --daddr xxx --dport xx
            - nat:      python -m pynft natdel  --project --ip --port
    """
    main()
