#!/usr/bin/env python
# -*- encoding=utf8 -*-

"""

 author:  Konia Zheng
 mail:    konia@maxln.com
 time:    2017.06.08

 file:          nftnat.py
 description:   nftables nat handle.

"""

import re

from nft import NFT


class NFTNat(NFT):
    def __init__(self, **kwargs):
        super(NFTNat, self).__init__(**kwargs)

        self.nat_table = kwargs.setdefault("nat_table", "nat")
        self.nat_prerouting = kwargs.setdefault("nat_prerouting", "prerouting")
        self.nat_postrouting = kwargs.setdefault("nat_postrouting", "postrouting")
        self.map_ipaddr = kwargs.setdefault("map_ipaddr", "%s-%s_port_to_addr")
        self.map_port = kwargs.setdefault("map_port", "%s-%s_port_to_port")

    def _init_nat_prerouting(self, **kwargs):
        return self.operate_chain("add", self.nat_table, self.nat_prerouting, type="nat", hook="prerouting", **kwargs)

    def _init_nat_postrouting(self, **kwargs):
        return self.operate_chain("add", self.nat_table, self.nat_postrouting, type="nat", hook="postrouting", **kwargs)

    @property
    def postrouting(self):
        """
        {
                "eth0": ['8.8.8.8', handle]
        }
        :return: 
        """
        rule_set = {}

        if self.nat_table not in self.rules or self.nat_postrouting not in self.rules[self.nat_table]:
            return rule_set

        for handle, snat_rule in self.rules[self.nat_table][self.nat_postrouting].iteritems():
            rule_match = re.findall(r'"([^"]+)" snat to ([0-9.]+)', snat_rule)
            if rule_match:
                interface, ipaddr = rule_match[0]
                rule_set[interface] = [ipaddr, handle]

        return rule_set

    def prerouting(self, protocol="tcp"):
        """
        Match Prerouting rule 
            # ip daddr xx.xx.xx.xx dnat to tcp dport map @imp-ipaddr_port_to_addr:tcp dport map @imp-ipaddr_port_to_port
        :param protocol: 
        :return: rule_set = {"project": {ipaddr: handle}}
        """
        rule_set = {}

        if self.nat_table not in self.rules or self.nat_prerouting not in self.rules[self.nat_table]:
            return rule_set

        for handle, dnat_rule in self.rules[self.nat_table][self.nat_prerouting].iteritems():
            dnat_rules = re.findall(r'ip daddr ([0-9.]+) dnat to {0} dport map @([^:]+):{0} dport map @([^ ]+)'.format(
                protocol), dnat_rule)

            if not dnat_rules:
                continue

            ipaddr, portmap_ipaddr, portmap_port = dnat_rules[0]
            project = portmap_ipaddr.split("-")[0]

            if project in rule_set:
                if ipaddr not in rule_set[project]:
                    rule_set[project][ipaddr] = handle
            else:
                rule_set[project] = {ipaddr: handle}

        return rule_set

    @property
    def tcp_prerouting(self):
        return self.prerouting("tcp")

    @property
    def udp_prerouting(self):
        return self.prerouting("udp")

    @property
    def nat_elements(self):
        return self.elements.get(self.nat_table, {})

    def init_snat(self):
        for interface, ipaddr in self.ipaddr.iteritems():
            if interface not in self.postrouting:
                rule = """oif %s snat %s""" % (interface, ipaddr)
                self.operate_rule("add", self.nat_table, self.nat_postrouting, rule)

    def init_nat(self, **kwargs):
        if kwargs.get("table"):
            self.nat_table = kwargs["table"]

        if kwargs.get("prerouting"):
            self.nat_prerouting = kwargs["prerouting"]

        if kwargs.get("postrouting"):
            self.nat_postrouting = kwargs["postrouting"]

        # init table
        if self.nat_table not in self.tables:
            self.operate_table("add", self.nat_table, **kwargs)

        # init prerouting chain
        self._init_nat_prerouting(**kwargs)

        # init postrouting chain
        self._init_nat_postrouting(**kwargs)

        # init snat rule
        self.init_snat()

        return 0, "init done"

    def init_map(self, project, nat_ip):
        portmap_ipaddr = self.map_ipaddr % (project, nat_ip)
        portmap_port = self.map_port % (project, nat_ip)

        self.operate_map("init", self.nat_table, portmap_ipaddr, map_type=["inet_service", "ipv4_addr"])
        self.operate_map("init", self.nat_table, portmap_port, map_type=["inet_service", "inet_service"])

        return portmap_ipaddr, portmap_port

    def _list_map_ip(self, project):
        """
        return map ip addr list
        :param project: 
        :return: 
        """
        result = []
        if self.nat_table not in self.maps:
            return result

        for item in self.maps[self.nat_table]:
            map_project = item.split("-")[0]
            map_ipaddr = item.split("-")[1].split("_")[0]

            if not project or map_project == project:
                if map_project in result:
                    if map_ipaddr not in result[map_project]:
                        result[map_project].append(map_ipaddr)
                else:
                    result[map_project] = [map_ipaddr]

        return result

    def _list_element(self, map_name):
        return dict(self.elements.get(self.nat_table, {}).get(map_name, {}))

    def list_project_element(self, project, nat_ip=None):
        result_table = {
            "project": project,
            "items": {}
        }

        for item, value in self.nat_elements.iteritems():
            if item.startswith("%s-" % project):
                ipaddr = item.split("%s-" % project)[1].split("_")[0]

                if nat_ip and nat_ip != ipaddr:
                    continue

                port_hash = "dport" if item.endswith("port") else "daddr"

                if ipaddr not in result_table["items"]:
                    result_table["items"][ipaddr] = {}

                for port, port_value in value.iteritems():
                    if port in result_table["items"][ipaddr]:
                        result_table["items"][ipaddr][port][port_hash] = port_value
                    else:
                        result_table["items"][ipaddr][port] = {port_hash: port_value}

        return result_table

    def list_ip_element(self, nat_ip):
        """
        nat_ip: 
        {"nat_ip": {"PORT": {"project": "xx", "DADDR": "", "dport": ""}}}
        """
        result = {}
        for item, value in self.nat_elements.iteritems():
            project = item.split("-")[0]
            ipaddr = item.split("-")[1].split("_")[0]

            port_hash = "dport" if item.endswith("port") else "daddr"

            if nat_ip and ipaddr != nat_ip:
                continue

            if ipaddr not in result:
                result[ipaddr] = {}

            for port, port_value in value.iteritems():
                if port in result[ipaddr]:
                    result[ipaddr][port][port_hash] = port_value
                    result[ipaddr][port]["project"] = project
                else:
                    result[ipaddr][port] = {"project": project, port_hash: port_value}

        return result

    def flush_map(self, project, nat_ip):
        portmap_ipaddr, portmap_port = self.init_map(project, nat_ip)
        map_port_ipaddr = self._list_element(portmap_ipaddr)
        map_port_port = self._list_element(portmap_port)

        self.operate_map("pop", self.nat_table, portmap_ipaddr, element=map_port_ipaddr)
        self.operate_map("pop", self.nat_table, portmap_port, element=map_port_port)

        return self.list_project_element(project, nat_ip)

    def delete_map(self, project, nat_ip):
        portmap_ipaddr, portmap_port = self.init_map(project, nat_ip)
        self.operate_map("delete", self.nat_table, portmap_ipaddr)
        self.operate_map("delete", self.nat_table, portmap_port)

        return 0, "delete map done"

    def add_element(self, project, nat_ip, nat_port, daddr, dport):
        portmap_ipaddr, portmap_port = self.init_map(project, nat_ip)

        self.operate_map("add", self.nat_table, portmap_ipaddr, element={nat_port: daddr})
        self.operate_map("add", self.nat_table, portmap_port, element={nat_port: dport})

        return self.list_project_element(project, nat_ip)

    def update_element(self, project, nat_ip, nat_port, daddr="", dport="", **kwargs):
        replace = kwargs.setdefault("replace", True)
        remove = kwargs.setdefault("remove", False)

        portmap_ipaddr, portmap_port = self.init_map(project, nat_ip)
        map_port_ipaddr = self._list_element(portmap_ipaddr)
        map_port_port = self._list_element(portmap_port)

        if nat_port in map_port_ipaddr:
            if remove or daddr and map_port_ipaddr[nat_port] != daddr:
                self.operate_map("pop", self.nat_table, portmap_ipaddr, element={nat_port: map_port_ipaddr[nat_port]})

                if replace:
                    self.operate_map("add", self.nat_table, portmap_ipaddr, element={nat_port: daddr})
        elif not remove:
            self.operate_map("add", self.nat_table, portmap_ipaddr, element={nat_port: daddr})

        if nat_port in map_port_port:
            if remove or dport and map_port_port[nat_port] != dport:
                self.operate_map("pop", self.nat_table, portmap_port, element={nat_port: map_port_port[nat_port]})
                if replace:
                    self.operate_map("add", self.nat_table, portmap_port, element={nat_port: dport})
        elif not remove:
            self.operate_map("add", self.nat_table, portmap_port, element={nat_port: dport})

        return self.list_project_element(project, nat_ip)

    def update_element_list(self, project, nat_ip, port_daddr_list, port_dport_list):
        portmap_ipaddr, portmap_port = self.init_map(project, nat_ip)
        map_port_ipaddr = self._list_element(portmap_ipaddr)
        map_port_port = self._list_element(portmap_port)

        pop_port_daddr = {}
        for item in port_daddr_list:
            if item in map_port_ipaddr:
                new_value = port_daddr_list[item]
                old_value = map_port_ipaddr[item]

                if new_value != old_value:
                    pop_port_daddr[item] = old_value
                else:
                    port_daddr_list.pop(item)

        pop_port_dport = {}
        for item in port_dport_list:
            if item in map_port_port:
                new_value = port_dport_list[item]
                old_value = map_port_port[item]

                if new_value != old_value:
                    pop_port_dport[item] = old_value
                else:
                    port_dport_list.pop(item)

        if pop_port_daddr:
            self.operate_map("pop", self.nat_table, portmap_ipaddr, element=pop_port_daddr)

        if pop_port_dport:
            self.operate_map("pop", self.nat_table, portmap_port, element=pop_port_dport)

        self.operate_map("add", self.nat_table, portmap_ipaddr, element=port_daddr_list)
        self.operate_map("add", self.nat_table, portmap_port, element=port_dport_list)

        return self.list_project_element(project, nat_ip)

    def delete_element_list(self, project, nat_ip, port_daddr_list, port_dport_list):
        portmap_ipaddr, portmap_port = self.init_map(project, nat_ip)
        map_port_ipaddr = self._list_element(portmap_ipaddr)
        map_port_port = self._list_element(portmap_port)

        for port in port_daddr_list:
            if port not in map_port_ipaddr:
                port_daddr_list.pop(port)

        for port in port_dport_list:
            if port not in map_port_port:
                port_dport_list.pop(port)

        self.operate_map("pop", self.nat_table, portmap_ipaddr, element=port_daddr_list)
        self.operate_map("pop", self.nat_table, portmap_port, element=port_dport_list)

        return self.list_project_element(project, nat_ip)

    def add_dnat(self, project, nat_ip, protocol="tcp", check_ip=True):
        """
        dnat to tcp dport map @map_ipaddr : tcp dport map @map_port
        """
        if check_ip and nat_ip not in self.ipaddr.values():
            return 1, "ip addr [%s] is illegal" % nat_ip

        portmap_ipaddr, portmap_port = self.init_map(project, nat_ip)
        rule = """ip daddr {0} dnat to {1} dport map @{2} : {1} dport map @{3}""".format(
            nat_ip, protocol, portmap_ipaddr, portmap_port)
        return self.operate_rule("add", self.nat_table, self.nat_prerouting, rule)

    def del_dnat(self, project, nat_ip, protocol="tcp"):
        dnat_map_hash = self.prerouting(protocol)

        if project in dnat_map_hash and nat_ip in dnat_map_hash[project]:
            return self.operate_rule("delete", self.nat_table, self.nat_prerouting, None,
                                     handle=dnat_map_hash[project][nat_ip])

        return 0, "project dnat rule [%s:%s] not exist" % (project, nat_ip)


if __name__ == '__main__':
    import sys

    nft_handle = NFTNat()

    if len(sys.argv) > 1:
        cmd_arg = sys.argv[1]
        cmd_method = getattr(nft_handle, cmd_arg, None)

        if cmd_method:
            print cmd_method(*sys.argv[2:])
        else:
            print "not support method"
