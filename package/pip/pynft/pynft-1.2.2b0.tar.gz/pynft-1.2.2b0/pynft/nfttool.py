#!/usr/bin/env python
# -*- encoding=utf8 -*-

"""

 author:  Konia Zheng
 mail:    konia@maxln.com
 time:    2017.06.08

 file:          nfttool.py
 description:   `python -m pynft **` function handle.

"""

import os
import json
from nftnat import NFTNat


class NFTTool(object):
    def __init__(self):
        self.handle = NFTNat()

    @staticmethod
    def _tty_size():
        return os.popen('stty size', 'r').read().split()

    def _tty_title(self, title, tag="="):
        _, columns = self._tty_size()
        split_num = (int(columns) - 18 - len(title)) / 2
        return " ".join([tag * split_num, title, tag * split_num])

    def list(self, **kwargs):
        for item, value in kwargs.iteritems():
            list_value = getattr(self.handle, item, None)
            if value and list_value is not None:
                print self._tty_title(item.capitalize())
                print json.dumps(list_value, indent=2)

    def save(self, **kwargs):
        filename = kwargs.get("file", "")

        if filename:
            file_path = os.path.abspath(filename)
            dir_path = os.path.dirname(file_path)

            if os.path.exists(dir_path):
                status, output = self.handle.operate_ruleset("save", file=file_path)

                if status == 0:
                    print "ruleset save as %s" % file_path
                else:
                    print "ruleset save error. \n%s" % output
            else:
                print "file path illegal"
        else:
            print "file path null"

    def restore(self, **kwargs):
        filename = kwargs.get("file", "")

        if filename and os.path.isfile(filename):
            # have to empty rules to restore
            self.handle.operate_ruleset("flush")

            status, output = self.handle.operate_ruleset("load", file=filename)
            if status == 0:
                print "ruleset recover from %s" % filename
            else:
                print "ruleset save error. \n%s" % output
        else:
            print "file path illegal"

    def natinit(self, project, ip, **kwargs):
        self.handle.init_nat()
        if kwargs.get("enable_tcp"):
            self.handle.add_dnat(project, ip, protocol="tcp")

        if kwargs.get("enable_udp"):
            self.handle.add_dnat(project, ip, protocol="udp")

    def natclear(self, project, ip, **kwargs):
        if kwargs.get("enable_tcp"):
            status, output = self.handle.del_dnat(project, ip, protocol="tcp")
            if status != 0:
                print output

        if kwargs.get("enable_udp"):
            status, output = self.handle.del_dnat(project, ip, protocol="udp")
            if status != 0:
                print output

        print "please run with --no-tcp/--with-udp"

    def natadd(self, project, ip, port, daddr, dport, **kwargs):
        result = self.handle.update_element(project, ip, port,
                                            daddr=daddr, dport=dport, remove=False, replace=True,
                                            **kwargs)
        print json.dumps(result, indent=2)

    def natpop(self, project, ip, port, **kwargs):
        result = self.handle.update_element(project, ip, port, remove=True, **kwargs)
        print json.dumps(result, indent=2)

    def natlist(self, **kwargs):
        print json.dumps(self.handle.list_project_element(kwargs["project"]), indent=2)
