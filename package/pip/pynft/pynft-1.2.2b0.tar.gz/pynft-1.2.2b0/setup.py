#!/usr/bin/env python
from setuptools import setup

setup(
    name='pynft',
    version='1.2.2-beta',
    description='nftables user api',
    url='https://github.com/Lozy/pynft',
    author='Konia Zheng',
    author_email='konia@maxln.com',
    license='MIT',
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Build Tools',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 2.7',
    ],
    keywords='nftables(nft) wrapper for python',
    packages=['pynft'],
    install_requires=[]
)