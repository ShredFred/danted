Pynft: Another nftables wrapper for python
==========================================

Actually, we do have `pyroute2 <https://github.com/svinota/pyroute2>`_, a pure python library to manage `nfnetlink` api and do lots of fantastic things. However, the `nftable` module of pyroute2 was still statying in developing for a year.
Compared with reading the source code of `NFTSocket` and found out how it works, I decided to use `nft` from command shell.
Surely, it has so many disadvantages that I put these operations in a temporary module -- `nft`.
By the time `pyroute2` was finished, this project will be a wrapper for `pyroute2-nftables` with a new nftables operation module.


Install
-----------

.. code-block:: python
    >>> pip install pynft -i https://public.sockd.info/package/pip/


Tips
------------

- Using `sudo` and make sure `sudo nft` is working.
- `commands` library is needed.
- `ip addr` should be working.
- Rewrite core file `nft.py`, if you do want to change something.


Usage
------------

- As a module
- As a script

check `docs/document.md` for more detail.
check `docs/nat.md` for nat usage detail.